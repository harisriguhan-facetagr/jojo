def dio():
    print("The World!!!!(Time stops)")
