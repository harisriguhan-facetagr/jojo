def joseph():
    print("Oh My God!!!")