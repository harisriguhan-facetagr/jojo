def jotaro():
    print("yare yare")