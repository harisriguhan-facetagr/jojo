# Jojo

package that shows the popular dialogue of dio,jotaro and joseph

## Installation

run the following line in your terminal

````
pip3 install jojo

````
if you want to do some development with this package execute the command below

```
pip install -e .[dev]

```
## Usage 


```
import dio

import jotaro

import joseph
```