def dio():
    return "The World!!!!(Time stops)"
