def joseph():
    return "Oh My God!!!"