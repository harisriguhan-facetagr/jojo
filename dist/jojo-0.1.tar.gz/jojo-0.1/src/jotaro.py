def jotaro():
    return "yare yare"